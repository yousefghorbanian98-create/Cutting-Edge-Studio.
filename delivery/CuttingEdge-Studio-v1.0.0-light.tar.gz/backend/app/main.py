"""FastAPI application factory for the Cutting Edge v2 backend sidecar."""

from __future__ import annotations

import contextlib
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api import (
    assets,
    health,
    inspection,
    post,
    projects,
    render,
    settings_api,
    stylematch,
    system,
    uploads,
    workspace,
)
from app.config import ALLOWED_ORIGINS, API_PREFIX, Settings, get_settings
from app.security import SecurityMiddleware
from app.db import create_db_engine, create_session_factory, init_db
from app.desktop import clear_receipt, mount_frontend, publish_receipt
from app.logging import configure_logging, get_logger
from app.services.audio.processor import FFmpegRhythmInspector
from app.services.inference.registry import InferenceRegistry
from app.services.media.inspection import FFmpegInspector, InspectionService
from app.services.media.jobs import JobRegistry
from app.services.media.scenes import FFmpegSceneInspector
from app.services.media.service import MediaService, Prober
from app.services.media.workspaces import recover_workspaces
from app.services.stylematch.analysis import AnalysisOrchestrator

LOG = get_logger(__name__)


def create_app(settings: Settings | None = None, prober: Prober | None = None) -> FastAPI:
    """Build the ASGI app bound to ``settings`` (explicit settings help tests)."""
    resolved = settings or get_settings()
    resolved.ensure_dirs()
    configure_logging(
        resolved.log_level,
        resolved.logs_dir / "backend.jsonl" if resolved.log_to_file else None,
    )

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        app.state.cache_recovery = recover_workspaces(resolved.cache_dir)
        engine = create_db_engine(resolved.database_url)
        init_db(engine)
        app.state.engine = engine
        app.state.session_factory = create_session_factory(engine)
        app.state.registry = InferenceRegistry()
        app.state.inspection = InspectionService(
            app.state.session_factory,
            app.state.jobs,
            FFmpegInspector(resolved),
            rhythm_inspector=FFmpegRhythmInspector(resolved),
            scene_inspector=FFmpegSceneInspector(resolved),
            analysis_inspector=AnalysisOrchestrator(resolved, app.state.registry),
        )
        from app.services.render.orchestrator import RenderService

        app.state.render = RenderService(app.state.session_factory, app.state.jobs, resolved)
        LOG.info(
            "backend.startup",
            version=resolved.version,
            data_dir=str(resolved.data_dir),
            offline=resolved.offline,
        )
        try:
            publish_receipt(resolved, listener_owned=app.state.desktop_listener_owned)
            yield
        finally:
            clear_receipt(resolved)
            app.state.inspection.shutdown()
            with contextlib.suppress(Exception):
                app.state.render.shutdown()
            engine.dispose()
            LOG.info("backend.shutdown")

    app = FastAPI(
        title="Cutting Edge v2",
        version=resolved.version,
        description="Local-first sports video editor backend. No telemetry, no network at runtime.",
        lifespan=lifespan,
    )
    app.state.desktop_listener_owned = False
    app.state.settings = resolved
    app.state.media_service = MediaService(resolved, prober)
    app.state.jobs = JobRegistry()
    app.add_middleware(SecurityMiddleware)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=list(ALLOWED_ORIGINS),
        allow_credentials=False,
        allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
        allow_headers=["content-type", "x-ces-token", "origin"],
    )
    for module in (
        health,
        settings_api,
        projects,
        assets,
        uploads,
        stylematch,
        post,
        render,
        system,
        workspace,
        inspection,
    ):
        app.include_router(module.router, prefix=API_PREFIX)
    if resolved.serve_frontend:
        mount_frontend(app, resolved)
    return app


app = create_app()

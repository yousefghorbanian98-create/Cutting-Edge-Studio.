"""inference service package."""

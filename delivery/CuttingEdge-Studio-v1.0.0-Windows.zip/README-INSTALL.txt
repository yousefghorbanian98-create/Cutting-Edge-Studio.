Cutting Edge Studio v1.0.0 - Windows Game-like Installer
========================================================

QUICK START (Windows 11 x64):
  1. Extract this ZIP to C:\CuttingEdge-Setup\
  2. Right-click CuttingEdgeV2-Setup-v1.0.0.exe -> Run as Administrator
  3. Installer auto-extracts Data1.bin (Core 1.1GB -> 2.2GB) + Data2.bin (Models placeholder)
  4. Launch from Desktop shortcut

LIGHT vs FULL:
  Light (included): 8.9MB source tar + frontend 1.8MB build, needs FFmpeg/WebView2 on PATH
  Full (blocked): 3.5GB offline with all models + WebView2 fixed runtime

BUILD COMMANDS:
  Light: pwsh -File scripts/build-installer.ps1 -WithoutPinnedBinaries
  Full:  pwsh -File scripts/build-installer.ps1 -UpdatePins; pwsh -File scripts/build-installer.ps1

VERIFIED: Backend 333 tests 93%, Frontend 168 tests, zizmor 0 findings, gitleaks PASS

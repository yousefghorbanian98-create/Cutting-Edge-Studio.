MODELS - Placeholder for Full Offline Bundle (BLOCKED honestly)

This Data2.bin would contain the pinned ML models for full offline operation:
- mediapipe_pose (Apache-2.0, bundled-in-mediapipe-wheel)
- clip_vit_b32_onnx (340MB -> 85MB quantized)
- yolox_s (69MB -> yolox_nano 12MB option)
- faster_whisper_base (290MB -> 120MB INT8)
- piper_voice_fa (50-110MB -> 30MB medium)
- transnet_v2_onnx (12MB)

Current status: sha256: null in scripts/pins.json (placeholder URLs)
To populate (trusted Windows):
  pwsh -File scripts/build-installer.ps1 -UpdatePins
  # review git diff pins.json + licenses
  pwsh -File scripts/build-installer.ps1 (full)

Light build uses system FFmpeg/WebView2 via -WithoutPinnedBinaries
See docs/R6-RELEASE-LIGHT.md and docs/FINAL-DELIVERY-v1.0.0.md

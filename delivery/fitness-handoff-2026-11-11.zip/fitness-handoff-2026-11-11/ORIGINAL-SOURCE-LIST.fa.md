# سابقه فهرست منابع مطرح‌شده

این فایل نام‌ها و ابهام‌های فهرست کاربر را برای نشست بعد حفظ می‌کند؛ نه ادعای دسترسی/مطالعه همه آثار، نه ممیزی علمی/حقوقی کامل، نه فهرست خرید. نسخه/مؤلف/ISBN بعضی عناوین روشن نشده است. شرط فعلی: بدون خرید یا دانلود منبع پولی جدید.

## ۱. تمام ۱۱ عنوان بخش رایگان کاربر

مجوز و تطبیق دقیق هر عنوان در [کاتالوگ](references/sources.json) است؛ «رایگان» در این فهرست به معنی مجوز عمومی بازاستفاده نیست.

1. **Open Textbook of Exercise Physiology** — شناسه `free-01`؛ وضعیت تطبیق: `publisher_page_matched_edition_check_required`.
2. **Anatomy and Physiology 2e** — شناسه `free-02`؛ وضعیت تطبیق: `current_openstax_web_version_matched_file_version_check_required`.
3. **Introduction to Kinesiology** — شناسه `free-03`؛ وضعیت تطبیق: `ambiguous_author_and_edition_required`.
4. **Essentials of Exercise and Sport Psychology: An Open Access Textbook** — شناسه `free-04`؛ وضعیت تطبیق: `publisher_page_matched_edition_check_required`.
5. **A Guide to Physical Activity** — شناسه `free-05`؛ وضعیت تطبیق: `publisher_page_matched_edition_check_required`.
6. **The Art of Lifting** — شناسه `free-06`؛ وضعیت تطبیق: `SBS_work_matched_file_edition_check_required`.
7. **The Science of Lifting** — شناسه `free-07`؛ وضعیت تطبیق: `SBS_work_matched_file_edition_check_required`.
8. **How to Bench** — شناسه `free-08`؛ وضعیت تطبیق: `conditional_match_user_author_confirmation_needed`.
9. **How to Deadlift** — شناسه `free-09`؛ وضعیت تطبیق: `conditional_match_user_author_confirmation_needed`.
10. **The Bulgarian Method** — شناسه `free-10`؛ وضعیت تطبیق: `conditional_match_title_and_author_confirmation_needed`.
11. **WHO Guidelines on Physical Activity and Sedentary Behaviour** — شناسه `free-11`؛ وضعیت تطبیق: `2020_publication_matched`.

## ۲. فهرست پولی/مقایسه‌ای قبلی، بدون ممیزی کامل

گروه‌بندی زیر برای نگهداری سابقه است و مؤلف‌بودن یک فرد برای همه کتاب‌های یک گروه را تأیید نمی‌کند. مجموعه‌های تمرینی و آثار نظری نیز واحدهای مساوی و مستقل دانش نیستند.

### عناوین فارسی/ترجمه، با نویسنده و ISBN/ویرایش هنوز نامشخص

- دایره‌المعارف بدنسازی و پرورش اندام نوین
- دایره‌المعارف مربیگری فیتنس
- طراحی تمرین حرفه‌ای در پرورش اندام
- حرکات اصلاحی به واسطه تمرینات با وزنه
- طراحی تمرین و نسخه‌نویسی در حرکات اصلاحی
- هرم مدرن تمرینات بدنسازی و تناسب اندام
- هرم مدرن غذایی بدنسازی و تناسب اندام
- هرم مدرن ریکاوری
- راهنمای جامع آماده‌سازی مسابقات بیلدینگ، کلاسیک، فیزیک: صفر تا صد (تمرین و تغذیه) کاهش وزن
- اصول و مبانی مربیگری فیتنس (ویژه مربیان)
- پیکرتراشی با چارلز گلس: اصول اولیه بدنسازی و فرم‌دهی بدن

### گروه Nippard در فهرست کاربر

- The Muscle Ladder: Get Jacked Using Science
- The Ultimate Guide to Body Recomposition
- Fundamentals Hypertrophy Program
- Pure Bodybuilding Program (Phase 1 & 2)
- Bodybuilding Transformation System
- The Essentials Program
- Upper/Lower Size and Strength Program
- Women’s Specialization Program

### عناوین گروه Diley/Dailey و موارد هم‌گروه فهرست کاربر؛ انتساب مؤلف تأییدشده فرض نشود

- FEASTMODE Cookbook
- Davis Diley Training Guides & DUP Manuals (MYLIFT)
- Scientific Principles of Hypertrophy Training
- The Renaissance Diet 2.0
- Recovering from Training: How to Manage Fatigue to Maximize Performance
- Fitter Faster: The Smart Way to Get in Shape in Just Minutes a Day
- Dailey Strengthening: 6 Keys to Balance Core Muscles for Optimal Health
- Holistic Bodybuilding: The Aging Antidote
- Achieving Total Muscularity
- Raw Muscularity

### گروه چهره‌ها/کتاب‌های عمومی در فهرست کاربر

- Bodybuilding Science: The Formula of Hypertrophy
- Bodybuilding Complete
- The New Encyclopedia of Modern Bodybuilding
- Heavy Duty
- Heavy Duty II: Mind and Body
- Blood and Guts
- Strength Training Anatomy
- Strong Curves

### گروه علمی/حرفه‌ای در فهرست کاربر

- Science and Development of Muscle Hypertrophy
- Scientific Principles of Hypertrophy Training
- The Muscle and Strength Pyramid: Training & Nutrition
- Hypertrophy: Muscle Fiber Growth Caused by Mechanical Tension
- NSCA’s Essentials of Strength Training and Conditioning
- ACSM’s Guidelines for Exercise Testing and Prescription
- Exercise Physiology: Nutrition, Energy, and Human Performance
- Physiology of Sport and Exercise
- Exercise Physiology: Theory and Application to Fitness and Performance
- Science and Practice of Strength Training
- Supertraining
- Serious Strength Training
- Outlive: The Science and Art of Longevity
- Becoming a Supple Leopard
- Back Mechanic
- Ultimate Back Fitness and Performance
- Movement
- Athletic Body in Balance
- Easy Strength
- Kettlebell Simple & Sinister
- Advances in Functional Training
- Functional Training for Sports

## ۳. اصلاحات و ابهام‌هایی که نباید گم شوند

- `Scientific Principles of Hypertrophy Training` در فهرست بیش از یک‌بار آمده؛ تکرار آن را شاهد یا دانش مستقل اضافه حساب نکنید. در تطبیق رسمی RP، مؤلفان Mike Israetel، James Hoffmann، Melissa Davis و Jared Feather هستند، نه Davis Diley.
- تطبیق ناشر/کتابفروشی ثبت‌شده برای `Bodybuilding Science: The Formula of Hypertrophy` نام Kevin P. Hunter را نشان داد، نه Charles Glass؛ ویرایش دقیق همچنان باید ثبت شود.
- عناوین فارسی بدون مؤلف/ISBN/ویرایش هویت یکتا ندارند. Diley/Dailey و `MYLIFT DUP Manuals` نیز نیازمند شناسایی دقیق‌اند.
- `Introduction to Kinesiology` هم‌نام‌های متفاوت دارد؛ نسخه Ragsdale/Schaefer 1.6 با سطح کتاب CC BY و استثنای اجزا را با نسخه Titus با NC-SA یکی نکنید.
- تطبیق `How to Bench` و `How to Deadlift` با راهنماهای SBS و `The Bulgarian Method` با Manual/Method آن مجموعه مشروط به تأیید هویت است.
- کتابی که از قبل با حق نگهداری قانونی در اختیار است، برای مطالعه لزوماً حذف نمی‌شود؛ اما متن/عکس/جدول/برنامه اختصاصی آن خودکار پیکره مجاز AI نیست.

ارجاعات و توضیح اصلاحات در [طرح اصلی](references/README.fa.md) و حقوق/تطبیق‌ها در [کاتالوگ](references/sources.json) آمده‌اند. هیچ full text در بسته نیست.

## ۴. منابع تکمیلیِ ثبت‌شده

این‌ها اضافه بر ۱۱ عنوان‌اند؛ تعدادشان یا مجوز مناسب‌تر، کفایت کل محصول را ثابت نمی‌کند. وضعیت هر قاعده همچنان تأییدنشده است.

- `additional-01` — Resistance Training Recommendations to Maximize Muscle Hypertrophy in an Athletic Population: Position Stand of the IUSCA (2021) — مجوز مشاهده‌شده `CC-BY-4.0`؛ URL/DOI و دامنه در کاتالوگ.
- `additional-02` — American College of Sports Medicine Position Stand. Resistance Training Prescription for Muscle Function, Hypertrophy, and Physical Performance in Healthy Adults: An Overview of Reviews (2026) — مجوز مشاهده‌شده `CC-BY-NC-ND-4.0`؛ URL/DOI و دامنه در کاتالوگ.
- `additional-03` — International Society of Sports Nutrition Position Stand: protein and exercise (2017) — مجوز مشاهده‌شده `CC-BY-4.0`؛ URL/DOI و دامنه در کاتالوگ.
- `additional-04` — Effects of Resistance Training on Physical Fitness in Healthy Children and Adolescents: An Umbrella Review (2020) — مجوز مشاهده‌شده `CC-BY-4.0`؛ URL/DOI و دامنه در کاتالوگ.
- `additional-05` — Effects of subjective and objective autoregulation methods for intensity and volume on enhancing maximal strength during resistance-training interventions: a systematic review (2021) — مجوز مشاهده‌شده `CC-BY-4.0`؛ URL/DOI و دامنه در کاتالوگ.
- `additional-06` — A Review on Aging, Sarcopenia, Falls, and Resistance Training in Community-Dwelling Older Adults (2022) — مجوز مشاهده‌شده `CC-BY-4.0`؛ URL/DOI و دامنه در کاتالوگ.
- `additional-07` — Sleep interventions in elite sport – a systematic review (2025) — مجوز مشاهده‌شده `CC-BY-4.0`؛ URL/DOI و دامنه در کاتالوگ.

چهار ارجاع پشتیبان نیز در کاتالوگ‌اند؛ برای ورود متن آن‌ها مجوز فرض نشده است. درصد پوشش منابع پولی هنوز محاسبه نشده و نباید از شمار عنوان‌ها ساخته شود.

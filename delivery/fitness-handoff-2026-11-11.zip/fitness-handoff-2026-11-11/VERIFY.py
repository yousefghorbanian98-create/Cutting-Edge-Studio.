#!/usr/bin/env python3
"""Read-only, offline integrity/structure checks for this handoff, not the app.

Read this script before running it. It uses Python's standard library, writes no
files, installs nothing, and performs no network requests or subprocess calls.
The unsigned manifest detects transfer changes, not authenticity or scientific,
legal, privacy, clinical, or application correctness.
"""

from __future__ import annotations

import csv
import hashlib
import json
import re
import sys
from pathlib import Path, PurePosixPath
from urllib.parse import unquote, urlsplit


class VerificationError(Exception):
    """A handoff file failed an integrity or structural check."""


def require(condition: bool, message: str) -> None:
    if not condition:
        raise VerificationError(message)


def digest(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            hasher.update(block)
    return hasher.hexdigest()


def load_json(root: Path, name: str) -> dict:
    value = json.loads((root / name).read_text(encoding="utf-8"))
    require(isinstance(value, dict), f"Expected a JSON object: {name}")
    return value


def load_csv(root: Path, name: str) -> list[dict[str, str]]:
    with (root / name).open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def checked_path(root: Path, relative: str) -> Path:
    require(isinstance(relative, str) and bool(relative), "Missing manifest path")
    pure = PurePosixPath(relative)
    require(
        not pure.is_absolute()
        and ".." not in pure.parts
        and "\\" not in relative
        and str(pure) == relative,
        f"Unsafe or noncanonical path: {relative}",
    )
    target = root / relative
    require(target.resolve().is_relative_to(root), f"Path escapes package: {relative}")
    require(not target.is_symlink(), f"Symlink is not allowed: {relative}")
    require(target.is_file(), f"Missing file: {relative}")
    return target


def verify_manifest(root: Path, manifest: dict) -> int:
    require(manifest.get("handoff_version") == "1.0.0", "Unexpected handoff version")
    entries = manifest.get("files")
    require(isinstance(entries, list) and bool(entries), "Manifest has no files")
    expected: set[str] = set()
    total_bytes = 0
    for entry in entries:
        require(isinstance(entry, dict), "Invalid manifest entry")
        name = entry.get("path")
        target = checked_path(root, name)
        require(name != "MANIFEST.json", "Manifest must not self-hash")
        require(name not in expected, f"Duplicate manifest path: {name}")
        expected.add(name)
        size = target.stat().st_size
        require(size == entry.get("bytes"), f"Size mismatch: {name}")
        require(digest(target) == entry.get("sha256"), f"SHA-256 mismatch: {name}")
        total_bytes += size

    actual: set[str] = set()
    for path in root.rglob("*"):
        require(not path.is_symlink(), f"Symlink found: {path.relative_to(root)}")
        if path.is_file():
            actual.add(path.relative_to(root).as_posix())
    require(actual == expected | {"MANIFEST.json"}, "Unlisted or missing package files")
    require(manifest.get("file_count_excluding_manifest") == len(expected), "File count mismatch")
    require(manifest.get("total_bytes_excluding_manifest") == total_bytes, "Byte count mismatch")
    return len(expected)


def verify_links_and_text(root: Path) -> None:
    for path in root.rglob("*.md"):
        text = path.read_text(encoding="utf-8")
        require(not any(line.rstrip() != line for line in text.splitlines()),
                f"Trailing whitespace: {path.relative_to(root)}")
        for raw in re.findall(r"\]\(([^)]+)\)", text):
            url = urlsplit(raw)
            if url.scheme or raw.startswith("#"):
                continue
            local = unquote(url.path)
            if not local:
                continue
            target = (path.parent / local).resolve()
            require(target.is_relative_to(root), f"Nonportable local link: {raw}")
            require(target.is_file(), f"Broken local link in {path.name}: {raw}")


def verify_catalog(root: Path) -> None:
    catalog = load_json(root, "references/sources.json")
    require(catalog.get("catalog_version") == "0.2.0", "Catalog version mismatch")
    groups = ("user_free_list", "additional_evidence", "supporting_references")
    require(tuple(len(catalog[name]) for name in groups) == (11, 7, 4), "Catalog counts changed")
    identifiers = [item["id"] for name in groups for item in catalog[name]]
    require(len(identifiers) == len(set(identifiers)), "Duplicate source IDs")
    require(catalog.get("coverage_percent") is None, "Coverage must remain uncomputed here")
    require(catalog.get("coverage_status") == "not_computed", "Coverage status changed")
    for flag in ("contains_full_text", "contains_athlete_data", "runtime_import_enabled"):
        require(catalog.get(flag) is False, f"Unexpected catalog flag: {flag}")
    require(all(item.get("rule_approval_status") == "no_executable_rules_approved"
                for item in catalog["additional_evidence"]), "Source-rule approval changed")
    require(sum(item.get("observed_license") == "CC-BY-4.0"
                for item in catalog["additional_evidence"]) == 6,
            "Expected six conditional CC BY additional candidates")

    audit = load_csv(root, "references/coverage-audit.template.csv")
    require(len(audit) == 13, "Expected 13 starter coverage rows")
    require(all(not row["weight"] and not row["coverage_score"] for row in audit),
            "Starter coverage template must not contain invented scores")


def verify_requirements(root: Path) -> None:
    spec = load_json(root, "REQUIREMENTS.json")
    require(spec.get("handoff_version") == "1.0.0", "Requirements version mismatch")
    require(spec["destination"]["independent_app"] is True, "Independent-app decision lost")
    require(spec["destination"]["already_in_development_per_user"] is True,
            "Existing destination work must not be assumed absent")
    require(spec["destination"]["inherit_video_editor_restrictions"] is False,
            "Do not inherit origin video-editor restrictions")
    require(spec["population_goal"]["all_ages_requested"] is True, "All-age goal lost")
    require(spec["population_goal"]["healthy_adult_only_approved_by_user"] is False,
            "Do not invent approval of a narrower population")
    require(spec["population_goal"]["universal_scientific_validation_established"] is False,
            "Universal validation was not established")
    require(spec["report_contract"]["identity_in_confidential_report"] is True,
            "Named confidential report requirement lost")
    require(spec["report_contract"]["all_input_data_visible_before_plan_body"] is True,
            "Complete front-matter requirement lost")

    domains = spec["domains"]
    audit = load_csv(root, "references/coverage-audit.template.csv")
    require(len(domains) == 13, "Expected 13 domains")
    require([(item["id"], item["name_fa"]) for item in domains]
            == [(row["item_id"], row["domain_fa"]) for row in audit],
            "Domain IDs or names differ between requirements and reference audit")
    template = (root / "references/RESEARCH-REPORT.template.fa.md").read_text(encoding="utf-8")
    require(all(item["name_fa"] in template for item in domains), "Report template omits a domain")
    require("{{نام کامل در نسخه محرمانه}}" in template, "Missing identity placeholder")
    require(template.index("## بخش آغازین ۷") < template.index("## خود برنامه پژوهشی"),
            "Dossier sections must precede the plan")

    decisions = spec["confirmed_user_decisions"]
    engineering = spec["engineering_requirements"]
    require(all(item["status"] == "confirmed_by_user" for item in decisions),
            "Confirmed decisions must be labelled")
    require(all(item["status"].startswith("proposed_acceptance_requirement") for item in engineering),
            "Do not label proposed engineering requirements as implemented")
    ids = [item["id"] for item in decisions + engineering]
    require(len(ids) == len(set(ids)), "Duplicate requirement IDs")

    tests = load_csv(root, "acceptance-tests.csv")
    test_ids = [row["test_id"] for row in tests]
    require(bool(tests) and len(test_ids) == len(set(test_ids)), "Empty or duplicate acceptance tests")
    require(all(row["status_origin"] == "not_run_in_origin" for row in tests),
            "Acceptance scenarios must not claim execution")
    require(all(not row["evidence_ref"] for row in tests), "Do not invent test artifacts")
    referenced: set[str] = set()
    for row in tests:
        refs = set(row["requirement_refs"].split(";"))
        require(refs <= set(ids), f"Unknown requirement reference in {row['test_id']}")
        referenced.update(refs)
    require(set(ids) <= referenced, "Some requirements have no proposed acceptance scenario")


def verify_reuse_and_rule_template(root: Path) -> None:
    reuse = load_json(root, "REUSE-INVENTORY.json")
    context = reuse["destination_context"]
    require(context["independent_app"] is True, "Reuse inventory has stale app context")
    require(context["origin_agpl_video_editor_blacklist_applies_automatically"] is False,
            "Origin AGPL policy must not be inherited")
    require(context["user_selected_base"] is None, "No final OSS base was selected by user")
    require(reuse["analysis_tool_candidate"]["run_on_fitness_apps"] is False,
            "Do not claim a REA run on fitness apps")
    components = reuse["components"]
    require(len(components) == 5, "Expected five initial reuse candidates")
    for item in components:
        require(re.fullmatch(r"[0-9a-f]{40}", item["reviewed_commit"]) is not None,
                f"Invalid pinned commit: {item['id']}")
        require(item["repo_url"].startswith("https://github.com/"), "Unexpected repository URL")
        require(item["tests_executed_in_origin"] is False and item["code_imported_in_origin"] is False,
                "Do not claim adopted or executed upstream code")
        require(item["scientific_approval"] == "not_established", "Scientific approval invented")
    rule = load_json(root, "templates/rule-evidence.template.json")
    require(rule["template_only"] is True and rule["execution_enabled"] is False
            and rule["runtime_import_enabled"] is False, "Rule template must remain inactive")
    require(rule["activation"]["approved"] is False, "Rule activation invented")
    require(rule["scientific_review"]["status"] == "unreviewed"
            and rule["rights_review"]["status"] == "unreviewed", "Rule review invented")


def main() -> int:
    root = Path(__file__).resolve().parent
    try:
        manifest = load_json(root, "MANIFEST.json")
        count = verify_manifest(root, manifest)
        verify_links_and_text(root)
        verify_catalog(root)
        verify_requirements(root)
        verify_reuse_and_rule_template(root)
    except (VerificationError, OSError, ValueError, KeyError, TypeError) as error:
        print(f"HANDOFF CHECK FAILED: {error}", file=sys.stderr)
        return 1
    print(f"HANDOFF CHECKS PASSED: {count} hashed files + unsigned manifest.")
    print("Integrity, local links, catalog counts, requirement/template consistency, and pending statuses checked.")
    print("NOT an app test, scientific validation, legal approval, privacy audit, or publisher-authenticity proof.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

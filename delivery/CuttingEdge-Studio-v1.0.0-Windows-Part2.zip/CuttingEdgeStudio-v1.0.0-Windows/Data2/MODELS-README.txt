MODELS - Placeholder for Full Offline Bundle (BLOCKED honestly)
==============================================================
This Data2 contains model placeholders. For Full 3.5GB offline:
  pwsh -File scripts/build-installer.ps1 -UpdatePins  (trusted network)
  pwsh -File scripts/build-installer.ps1              (full build)
Models: mediapipe_pose, clip_vit_b32_onnx (340MB->85MB quantized),
        yolox_s (69MB->12MB nano), faster_whisper_base (290MB->120MB INT8),
        piper_voice_fa, transnet_v2_onnx
See docs/R6-RELEASE-LIGHT.md
